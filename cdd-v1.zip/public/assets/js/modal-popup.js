$(function() {
	
	//Modal Popup
	$(document).on("click",".phone-button", function(e) {
		$('body').addClass('modal-open1');
	});
	
});